const photos = [
  "crocs-1.jpeg",
  "crocs-2.jpeg",
  "crocs-3.jpeg",
  "crocs-4.jpeg",
  "crocs-5.jpeg"
];

async function telegram(method, token, payload) {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!response.ok || !data.ok) throw new Error(data.description || "Telegram API request failed");
  return data;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).send("Method not allowed");

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const appUrl = (process.env.APP_URL || "").replace(/\/$/, "");
  const webhookSecret = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (!token || !appUrl || !webhookSecret) return res.status(500).send("Missing bot configuration");
  if (req.headers["x-telegram-bot-api-secret-token"] !== webhookSecret) return res.status(401).send("Unauthorized");

  const update = req.body;
  const message = update?.message;
  if (!message?.chat?.id || !message?.text) return res.status(200).json({ ok: true });

  const chatId = message.chat.id;
  const text = message.text.trim();
  if (text.startsWith("/start")) {
    const media = photos.map((file, index) => ({
      type: "photo",
      media: `${appUrl}/photos/${file}`,
      ...(index === 0 ? { caption: "🖤 black mega crush crocs — actual item photos 实物图\nSize: EU 38\nPre-loved; original box + charms shown included." } : {})
    }));
    await telegram("sendMessage", token, {
      chat_id: chatId,
      text: "here are the actual item photos 实物图 ♡\nplease check the photos for condition before bidding! 🖤"
    });
    await telegram("sendMediaGroup", token, { chat_id: chatId, media });
    return res.status(200).json({ ok: true });
  }

  await telegram("sendMessage", token, {
    chat_id: chatId,
    text: "hi ♡ send /start to view the actual product photos 实物图 🖤"
  });
  return res.status(200).json({ ok: true });
}
