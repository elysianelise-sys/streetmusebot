# StreetMuseBot — Telegram photo delivery

This Vercel project sends five actual Crocs photos as a Telegram album when someone opens the bot link and presses **Start**.

## Important
- Never share your Telegram bot token publicly.
- People must press **Start** before a Telegram bot can DM them.
- The five photos in `public/photos/` are publicly accessible from the deployed website so Telegram can fetch them. Do not put private or sensitive photos here.

## Deploy on Vercel
1. Upload this project to a GitHub repository, then import that repository into Vercel.
2. In Vercel → Project → Settings → Environment Variables, add:
   - `TELEGRAM_BOT_TOKEN` = token from BotFather (keep secret)
   - `APP_URL` = your deployed public URL, e.g. `https://your-project.vercel.app` (no trailing slash)
   - `TELEGRAM_WEBHOOK_SECRET` = a long random secret containing only letters, numbers, `_` or `-`
3. Redeploy after setting the variables.
4. Set the Telegram webhook by opening this URL in a browser, replacing the placeholders with your values (URL-encode the secret if needed):

   `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/setWebhook?url=https://<YOUR_PROJECT>.vercel.app/api/webhook&secret_token=<YOUR_WEBHOOK_SECRET>`

5. Test by opening `https://t.me/streetmusebot?start=shoes` and pressing **Start**.

## Change the photos
Replace the JPEGs in `public/photos/` and keep the filenames the same, or update the list in `api/webhook.js`. Commit and redeploy.

## Notes
- This is a template project; it has not been deployed or connected to your bot from this chat.
- The photo URLs are public. Anyone who obtains them may access the images directly.
